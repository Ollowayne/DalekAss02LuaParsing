function noLuaFunction()
	if functionEndMissing == true then
		example.noe()
	end