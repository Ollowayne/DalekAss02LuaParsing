README
------

PROJECT Lua parsing BY dalek

MEMBERS 
  Samuel Gros (213100855)
  Christopher Held (213100789)
  Philipp Seifer (213100788)

PARSED LANGUAGE
  Lua

TECHNOLOGIES
  (Java)
  ANTLR
  JUnit

DEPENDENCIES
  antlr-4.2.1-complete
  junit-4.11-sources
  junit-4.11
  hamcrest-core-1.3-sources
  hamcrest-core-1.3

DESCRIPTION
  Lua parser and pretty printer
  transformation: renaming any given number of names (identifiers)
  the project features examples as well as test cases
  no additional setup required 
