// Generated from Lua.g4 by ANTLR 4.2.2

	package ptt.dalek.antlr;
	

import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class LuaParser extends Parser {
	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		T__49=1, T__48=2, T__47=3, T__46=4, T__45=5, T__44=6, T__43=7, T__42=8, 
		T__41=9, T__40=10, T__39=11, T__38=12, T__37=13, T__36=14, T__35=15, T__34=16, 
		T__33=17, T__32=18, T__31=19, T__30=20, T__29=21, T__28=22, T__27=23, 
		T__26=24, T__25=25, T__24=26, T__23=27, T__22=28, T__21=29, T__20=30, 
		T__19=31, T__18=32, T__17=33, T__16=34, T__15=35, T__14=36, T__13=37, 
		T__12=38, T__11=39, T__10=40, T__9=41, T__8=42, T__7=43, T__6=44, T__5=45, 
		T__4=46, T__3=47, T__2=48, T__1=49, T__0=50, STRING=51, NAME=52, NUMBER=53, 
		HEXNUMBER=54, LUANUMBER=55, WS=56;
	public static final String[] tokenNames = {
		"<INVALID>", "'local'", "'or'", "'*'", "'['", "'<'", "'false'", "'<='", 
		"'nil'", "'}'", "'do'", "'%'", "')'", "'::'", "'='", "'goto'", "'repeat'", 
		"'..'", "']'", "'in'", "','", "'-'", "'while'", "'('", "':'", "'not'", 
		"'if'", "'until'", "'~='", "'{'", "'...'", "'and'", "'break'", "'else'", 
		"'true'", "'elseif'", "'^'", "'function'", "'.'", "'+'", "'for'", "'return'", 
		"'local function'", "';'", "'>'", "'then'", "'=='", "'/'", "'>='", "'#'", 
		"'end'", "STRING", "NAME", "NUMBER", "HEXNUMBER", "LUANUMBER", "WS"
	};
	public static final int
		RULE_chunk = 0, RULE_block = 1, RULE_stat = 2, RULE_retstat = 3, RULE_label = 4, 
		RULE_funcname = 5, RULE_varlist = 6, RULE_namelist = 7, RULE_explist = 8, 
		RULE_exp = 9, RULE_var = 10, RULE_prefixexp = 11, RULE_functioncall = 12, 
		RULE_args = 13, RULE_functiondef = 14, RULE_funcbody = 15, RULE_parlist = 16, 
		RULE_tableconstructor = 17, RULE_fieldlist = 18, RULE_field = 19, RULE_fieldsep = 20, 
		RULE_binop = 21, RULE_unop = 22;
	public static final String[] ruleNames = {
		"chunk", "block", "stat", "retstat", "label", "funcname", "varlist", "namelist", 
		"explist", "exp", "var", "prefixexp", "functioncall", "args", "functiondef", 
		"funcbody", "parlist", "tableconstructor", "fieldlist", "field", "fieldsep", 
		"binop", "unop"
	};

	@Override
	public String getGrammarFileName() { return "Lua.g4"; }

	@Override
	public String[] getTokenNames() { return tokenNames; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public LuaParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}
	public static class ChunkContext extends ParserRuleContext {
		public TerminalNode EOF() { return getToken(LuaParser.EOF, 0); }
		public BlockContext block() {
			return getRuleContext(BlockContext.class,0);
		}
		public ChunkContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_chunk; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LuaVisitor ) return ((LuaVisitor<? extends T>)visitor).visitChunk(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ChunkContext chunk() throws RecognitionException {
		ChunkContext _localctx = new ChunkContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_chunk);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(46); block();
			setState(47); match(EOF);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class BlockContext extends ParserRuleContext {
		public StatContext stat(int i) {
			return getRuleContext(StatContext.class,i);
		}
		public List<StatContext> stat() {
			return getRuleContexts(StatContext.class);
		}
		public RetstatContext retstat() {
			return getRuleContext(RetstatContext.class,0);
		}
		public BlockContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_block; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LuaVisitor ) return ((LuaVisitor<? extends T>)visitor).visitBlock(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BlockContext block() throws RecognitionException {
		BlockContext _localctx = new BlockContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_block);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(52);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << 1) | (1L << 10) | (1L << 13) | (1L << 15) | (1L << 16) | (1L << 22) | (1L << 23) | (1L << 26) | (1L << 32) | (1L << 37) | (1L << 40) | (1L << 42) | (1L << 43) | (1L << NAME))) != 0)) {
				{
				{
				setState(49); stat();
				}
				}
				setState(54);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(56);
			_la = _input.LA(1);
			if (_la==41) {
				{
				setState(55); retstat();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StatContext extends ParserRuleContext {
		public NamelistContext namelist() {
			return getRuleContext(NamelistContext.class,0);
		}
		public ExplistContext explist() {
			return getRuleContext(ExplistContext.class,0);
		}
		public VarlistContext varlist() {
			return getRuleContext(VarlistContext.class,0);
		}
		public FunctioncallContext functioncall() {
			return getRuleContext(FunctioncallContext.class,0);
		}
		public List<ExpContext> exp() {
			return getRuleContexts(ExpContext.class);
		}
		public BlockContext block(int i) {
			return getRuleContext(BlockContext.class,i);
		}
		public LabelContext label() {
			return getRuleContext(LabelContext.class,0);
		}
		public ExpContext exp(int i) {
			return getRuleContext(ExpContext.class,i);
		}
		public TerminalNode NAME() { return getToken(LuaParser.NAME, 0); }
		public FuncbodyContext funcbody() {
			return getRuleContext(FuncbodyContext.class,0);
		}
		public FuncnameContext funcname() {
			return getRuleContext(FuncnameContext.class,0);
		}
		public List<BlockContext> block() {
			return getRuleContexts(BlockContext.class);
		}
		public StatContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_stat; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LuaVisitor ) return ((LuaVisitor<? extends T>)visitor).visitStat(this);
			else return visitor.visitChildren(this);
		}
	}

	public final StatContext stat() throws RecognitionException {
		StatContext _localctx = new StatContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_stat);
		int _la;
		try {
			setState(138);
			switch ( getInterpreter().adaptivePredict(_input,6,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(58); match(43);
				}
				break;

			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(59); varlist();
				setState(60); match(14);
				setState(61); explist();
				}
				break;

			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(63); functioncall();
				}
				break;

			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(64); label();
				}
				break;

			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(65); match(32);
				}
				break;

			case 6:
				enterOuterAlt(_localctx, 6);
				{
				setState(66); match(15);
				setState(67); match(NAME);
				}
				break;

			case 7:
				enterOuterAlt(_localctx, 7);
				{
				setState(68); match(10);
				setState(69); block();
				setState(70); match(50);
				}
				break;

			case 8:
				enterOuterAlt(_localctx, 8);
				{
				setState(72); match(22);
				setState(73); exp(0);
				setState(74); match(10);
				setState(75); block();
				setState(76); match(50);
				}
				break;

			case 9:
				enterOuterAlt(_localctx, 9);
				{
				setState(78); match(16);
				setState(79); block();
				setState(80); match(27);
				setState(81); exp(0);
				}
				break;

			case 10:
				enterOuterAlt(_localctx, 10);
				{
				setState(83); match(26);
				setState(84); exp(0);
				setState(85); match(45);
				setState(86); block();
				setState(94);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==35) {
					{
					{
					setState(87); match(35);
					setState(88); exp(0);
					setState(89); match(45);
					setState(90); block();
					}
					}
					setState(96);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(99);
				_la = _input.LA(1);
				if (_la==33) {
					{
					setState(97); match(33);
					setState(98); block();
					}
				}

				setState(101); match(50);
				}
				break;

			case 11:
				enterOuterAlt(_localctx, 11);
				{
				setState(103); match(40);
				setState(104); match(NAME);
				setState(105); match(14);
				setState(106); exp(0);
				setState(107); match(20);
				setState(108); exp(0);
				setState(111);
				_la = _input.LA(1);
				if (_la==20) {
					{
					setState(109); match(20);
					setState(110); exp(0);
					}
				}

				setState(113); match(10);
				setState(114); block();
				setState(115); match(50);
				}
				break;

			case 12:
				enterOuterAlt(_localctx, 12);
				{
				setState(117); match(40);
				setState(118); namelist();
				setState(119); match(19);
				setState(120); explist();
				setState(121); match(10);
				setState(122); block();
				setState(123); match(50);
				}
				break;

			case 13:
				enterOuterAlt(_localctx, 13);
				{
				setState(125); match(37);
				setState(126); funcname();
				setState(127); funcbody();
				}
				break;

			case 14:
				enterOuterAlt(_localctx, 14);
				{
				setState(129); match(42);
				setState(130); match(NAME);
				setState(131); funcbody();
				}
				break;

			case 15:
				enterOuterAlt(_localctx, 15);
				{
				setState(132); match(1);
				setState(133); namelist();
				setState(136);
				_la = _input.LA(1);
				if (_la==14) {
					{
					setState(134); match(14);
					setState(135); explist();
					}
				}

				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class RetstatContext extends ParserRuleContext {
		public ExplistContext explist() {
			return getRuleContext(ExplistContext.class,0);
		}
		public RetstatContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_retstat; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LuaVisitor ) return ((LuaVisitor<? extends T>)visitor).visitRetstat(this);
			else return visitor.visitChildren(this);
		}
	}

	public final RetstatContext retstat() throws RecognitionException {
		RetstatContext _localctx = new RetstatContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_retstat);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(140); match(41);
			setState(142);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << 6) | (1L << 8) | (1L << 21) | (1L << 23) | (1L << 25) | (1L << 29) | (1L << 30) | (1L << 34) | (1L << 37) | (1L << 49) | (1L << STRING) | (1L << NAME) | (1L << NUMBER))) != 0)) {
				{
				setState(141); explist();
				}
			}

			setState(145);
			_la = _input.LA(1);
			if (_la==43) {
				{
				setState(144); match(43);
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class LabelContext extends ParserRuleContext {
		public TerminalNode NAME() { return getToken(LuaParser.NAME, 0); }
		public LabelContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_label; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LuaVisitor ) return ((LuaVisitor<? extends T>)visitor).visitLabel(this);
			else return visitor.visitChildren(this);
		}
	}

	public final LabelContext label() throws RecognitionException {
		LabelContext _localctx = new LabelContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_label);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(147); match(13);
			setState(148); match(NAME);
			setState(149); match(13);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FuncnameContext extends ParserRuleContext {
		public TerminalNode NAME(int i) {
			return getToken(LuaParser.NAME, i);
		}
		public List<TerminalNode> NAME() { return getTokens(LuaParser.NAME); }
		public FuncnameContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_funcname; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LuaVisitor ) return ((LuaVisitor<? extends T>)visitor).visitFuncname(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FuncnameContext funcname() throws RecognitionException {
		FuncnameContext _localctx = new FuncnameContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_funcname);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(151); match(NAME);
			setState(156);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==38) {
				{
				{
				setState(152); match(38);
				setState(153); match(NAME);
				}
				}
				setState(158);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(161);
			_la = _input.LA(1);
			if (_la==24) {
				{
				setState(159); match(24);
				setState(160); match(NAME);
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class VarlistContext extends ParserRuleContext {
		public VarContext var(int i) {
			return getRuleContext(VarContext.class,i);
		}
		public List<VarContext> var() {
			return getRuleContexts(VarContext.class);
		}
		public VarlistContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_varlist; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LuaVisitor ) return ((LuaVisitor<? extends T>)visitor).visitVarlist(this);
			else return visitor.visitChildren(this);
		}
	}

	public final VarlistContext varlist() throws RecognitionException {
		VarlistContext _localctx = new VarlistContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_varlist);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(163); var();
			setState(168);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==20) {
				{
				{
				setState(164); match(20);
				setState(165); var();
				}
				}
				setState(170);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class NamelistContext extends ParserRuleContext {
		public TerminalNode NAME(int i) {
			return getToken(LuaParser.NAME, i);
		}
		public List<TerminalNode> NAME() { return getTokens(LuaParser.NAME); }
		public NamelistContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_namelist; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LuaVisitor ) return ((LuaVisitor<? extends T>)visitor).visitNamelist(this);
			else return visitor.visitChildren(this);
		}
	}

	public final NamelistContext namelist() throws RecognitionException {
		NamelistContext _localctx = new NamelistContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_namelist);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(171); match(NAME);
			setState(176);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,12,_ctx);
			while ( _alt!=2 && _alt!=ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(172); match(20);
					setState(173); match(NAME);
					}
					} 
				}
				setState(178);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,12,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ExplistContext extends ParserRuleContext {
		public List<ExpContext> exp() {
			return getRuleContexts(ExpContext.class);
		}
		public ExpContext exp(int i) {
			return getRuleContext(ExpContext.class,i);
		}
		public ExplistContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_explist; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LuaVisitor ) return ((LuaVisitor<? extends T>)visitor).visitExplist(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ExplistContext explist() throws RecognitionException {
		ExplistContext _localctx = new ExplistContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_explist);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(179); exp(0);
			setState(184);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==20) {
				{
				{
				setState(180); match(20);
				setState(181); exp(0);
				}
				}
				setState(186);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ExpContext extends ParserRuleContext {
		public PrefixexpContext prefixexp() {
			return getRuleContext(PrefixexpContext.class,0);
		}
		public BinopContext binop() {
			return getRuleContext(BinopContext.class,0);
		}
		public UnopContext unop() {
			return getRuleContext(UnopContext.class,0);
		}
		public FunctiondefContext functiondef() {
			return getRuleContext(FunctiondefContext.class,0);
		}
		public List<ExpContext> exp() {
			return getRuleContexts(ExpContext.class);
		}
		public TableconstructorContext tableconstructor() {
			return getRuleContext(TableconstructorContext.class,0);
		}
		public ExpContext exp(int i) {
			return getRuleContext(ExpContext.class,i);
		}
		public TerminalNode NUMBER() { return getToken(LuaParser.NUMBER, 0); }
		public TerminalNode STRING() { return getToken(LuaParser.STRING, 0); }
		public ExpContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_exp; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LuaVisitor ) return ((LuaVisitor<? extends T>)visitor).visitExp(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ExpContext exp() throws RecognitionException {
		return exp(0);
	}

	private ExpContext exp(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		ExpContext _localctx = new ExpContext(_ctx, _parentState);
		ExpContext _prevctx = _localctx;
		int _startState = 18;
		enterRecursionRule(_localctx, 18, RULE_exp, _p);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(200);
			switch (_input.LA(1)) {
			case 21:
			case 25:
			case 49:
				{
				setState(188); unop();
				setState(189); exp(1);
				}
				break;
			case 8:
				{
				setState(191); match(8);
				}
				break;
			case 6:
				{
				setState(192); match(6);
				}
				break;
			case 34:
				{
				setState(193); match(34);
				}
				break;
			case NUMBER:
				{
				setState(194); match(NUMBER);
				}
				break;
			case STRING:
				{
				setState(195); match(STRING);
				}
				break;
			case 30:
				{
				setState(196); match(30);
				}
				break;
			case 37:
				{
				setState(197); functiondef();
				}
				break;
			case 23:
			case NAME:
				{
				setState(198); prefixexp(0);
				}
				break;
			case 29:
				{
				setState(199); tableconstructor();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			_ctx.stop = _input.LT(-1);
			setState(208);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,15,_ctx);
			while ( _alt!=2 && _alt!=ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					{
					_localctx = new ExpContext(_parentctx, _parentState);
					pushNewRecursionContext(_localctx, _startState, RULE_exp);
					setState(202);
					if (!(precpred(_ctx, 2))) throw new FailedPredicateException(this, "precpred(_ctx, 2)");
					setState(203); binop();
					setState(204); exp(3);
					}
					} 
				}
				setState(210);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,15,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	public static class VarContext extends ParserRuleContext {
		public PrefixexpContext prefixexp() {
			return getRuleContext(PrefixexpContext.class,0);
		}
		public ExpContext exp() {
			return getRuleContext(ExpContext.class,0);
		}
		public TerminalNode NAME() { return getToken(LuaParser.NAME, 0); }
		public VarContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_var; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LuaVisitor ) return ((LuaVisitor<? extends T>)visitor).visitVar(this);
			else return visitor.visitChildren(this);
		}
	}

	public final VarContext var() throws RecognitionException {
		VarContext _localctx = new VarContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_var);
		try {
			setState(221);
			switch ( getInterpreter().adaptivePredict(_input,16,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(211); match(NAME);
				}
				break;

			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(212); prefixexp(0);
				setState(213); match(4);
				setState(214); exp(0);
				setState(215); match(18);
				}
				break;

			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(217); prefixexp(0);
				setState(218); match(38);
				setState(219); match(NAME);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class PrefixexpContext extends ParserRuleContext {
		public PrefixexpContext prefixexp() {
			return getRuleContext(PrefixexpContext.class,0);
		}
		public ExpContext exp() {
			return getRuleContext(ExpContext.class,0);
		}
		public TerminalNode NAME() { return getToken(LuaParser.NAME, 0); }
		public ArgsContext args() {
			return getRuleContext(ArgsContext.class,0);
		}
		public PrefixexpContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_prefixexp; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LuaVisitor ) return ((LuaVisitor<? extends T>)visitor).visitPrefixexp(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PrefixexpContext prefixexp() throws RecognitionException {
		return prefixexp(0);
	}

	private PrefixexpContext prefixexp(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		PrefixexpContext _localctx = new PrefixexpContext(_ctx, _parentState);
		PrefixexpContext _prevctx = _localctx;
		int _startState = 22;
		enterRecursionRule(_localctx, 22, RULE_prefixexp, _p);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(229);
			switch (_input.LA(1)) {
			case NAME:
				{
				setState(224); match(NAME);
				}
				break;
			case 23:
				{
				setState(225); match(23);
				setState(226); exp(0);
				setState(227); match(12);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			_ctx.stop = _input.LT(-1);
			setState(247);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,19,_ctx);
			while ( _alt!=2 && _alt!=ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					setState(245);
					switch ( getInterpreter().adaptivePredict(_input,18,_ctx) ) {
					case 1:
						{
						_localctx = new PrefixexpContext(_parentctx, _parentState);
						pushNewRecursionContext(_localctx, _startState, RULE_prefixexp);
						setState(231);
						if (!(precpred(_ctx, 5))) throw new FailedPredicateException(this, "precpred(_ctx, 5)");
						setState(232); match(4);
						setState(233); exp(0);
						setState(234); match(18);
						}
						break;

					case 2:
						{
						_localctx = new PrefixexpContext(_parentctx, _parentState);
						pushNewRecursionContext(_localctx, _startState, RULE_prefixexp);
						setState(236);
						if (!(precpred(_ctx, 4))) throw new FailedPredicateException(this, "precpred(_ctx, 4)");
						setState(237); match(38);
						setState(238); match(NAME);
						}
						break;

					case 3:
						{
						_localctx = new PrefixexpContext(_parentctx, _parentState);
						pushNewRecursionContext(_localctx, _startState, RULE_prefixexp);
						setState(239);
						if (!(precpred(_ctx, 3))) throw new FailedPredicateException(this, "precpred(_ctx, 3)");
						setState(240); args();
						}
						break;

					case 4:
						{
						_localctx = new PrefixexpContext(_parentctx, _parentState);
						pushNewRecursionContext(_localctx, _startState, RULE_prefixexp);
						setState(241);
						if (!(precpred(_ctx, 2))) throw new FailedPredicateException(this, "precpred(_ctx, 2)");
						setState(242); match(24);
						setState(243); match(NAME);
						setState(244); args();
						}
						break;
					}
					} 
				}
				setState(249);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,19,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	public static class FunctioncallContext extends ParserRuleContext {
		public PrefixexpContext prefixexp() {
			return getRuleContext(PrefixexpContext.class,0);
		}
		public TerminalNode NAME() { return getToken(LuaParser.NAME, 0); }
		public ArgsContext args() {
			return getRuleContext(ArgsContext.class,0);
		}
		public FunctioncallContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_functioncall; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LuaVisitor ) return ((LuaVisitor<? extends T>)visitor).visitFunctioncall(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FunctioncallContext functioncall() throws RecognitionException {
		FunctioncallContext _localctx = new FunctioncallContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_functioncall);
		try {
			setState(258);
			switch ( getInterpreter().adaptivePredict(_input,20,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(250); prefixexp(0);
				setState(251); args();
				}
				break;

			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(253); prefixexp(0);
				setState(254); match(24);
				setState(255); match(NAME);
				setState(256); args();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ArgsContext extends ParserRuleContext {
		public ExplistContext explist() {
			return getRuleContext(ExplistContext.class,0);
		}
		public TableconstructorContext tableconstructor() {
			return getRuleContext(TableconstructorContext.class,0);
		}
		public TerminalNode STRING() { return getToken(LuaParser.STRING, 0); }
		public ArgsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_args; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LuaVisitor ) return ((LuaVisitor<? extends T>)visitor).visitArgs(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ArgsContext args() throws RecognitionException {
		ArgsContext _localctx = new ArgsContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_args);
		int _la;
		try {
			setState(267);
			switch (_input.LA(1)) {
			case 23:
				enterOuterAlt(_localctx, 1);
				{
				setState(260); match(23);
				setState(262);
				_la = _input.LA(1);
				if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << 6) | (1L << 8) | (1L << 21) | (1L << 23) | (1L << 25) | (1L << 29) | (1L << 30) | (1L << 34) | (1L << 37) | (1L << 49) | (1L << STRING) | (1L << NAME) | (1L << NUMBER))) != 0)) {
					{
					setState(261); explist();
					}
				}

				setState(264); match(12);
				}
				break;
			case 29:
				enterOuterAlt(_localctx, 2);
				{
				setState(265); tableconstructor();
				}
				break;
			case STRING:
				enterOuterAlt(_localctx, 3);
				{
				setState(266); match(STRING);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FunctiondefContext extends ParserRuleContext {
		public FuncbodyContext funcbody() {
			return getRuleContext(FuncbodyContext.class,0);
		}
		public FunctiondefContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_functiondef; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LuaVisitor ) return ((LuaVisitor<? extends T>)visitor).visitFunctiondef(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FunctiondefContext functiondef() throws RecognitionException {
		FunctiondefContext _localctx = new FunctiondefContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_functiondef);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(269); match(37);
			setState(270); funcbody();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FuncbodyContext extends ParserRuleContext {
		public ParlistContext parlist() {
			return getRuleContext(ParlistContext.class,0);
		}
		public BlockContext block() {
			return getRuleContext(BlockContext.class,0);
		}
		public FuncbodyContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_funcbody; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LuaVisitor ) return ((LuaVisitor<? extends T>)visitor).visitFuncbody(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FuncbodyContext funcbody() throws RecognitionException {
		FuncbodyContext _localctx = new FuncbodyContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_funcbody);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(272); match(23);
			setState(274);
			_la = _input.LA(1);
			if (_la==30 || _la==NAME) {
				{
				setState(273); parlist();
				}
			}

			setState(276); match(12);
			setState(277); block();
			setState(278); match(50);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ParlistContext extends ParserRuleContext {
		public NamelistContext namelist() {
			return getRuleContext(NamelistContext.class,0);
		}
		public ParlistContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_parlist; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LuaVisitor ) return ((LuaVisitor<? extends T>)visitor).visitParlist(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ParlistContext parlist() throws RecognitionException {
		ParlistContext _localctx = new ParlistContext(_ctx, getState());
		enterRule(_localctx, 32, RULE_parlist);
		int _la;
		try {
			setState(286);
			switch (_input.LA(1)) {
			case NAME:
				enterOuterAlt(_localctx, 1);
				{
				setState(280); namelist();
				setState(283);
				_la = _input.LA(1);
				if (_la==20) {
					{
					setState(281); match(20);
					setState(282); match(30);
					}
				}

				}
				break;
			case 30:
				enterOuterAlt(_localctx, 2);
				{
				setState(285); match(30);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class TableconstructorContext extends ParserRuleContext {
		public FieldlistContext fieldlist() {
			return getRuleContext(FieldlistContext.class,0);
		}
		public TableconstructorContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_tableconstructor; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LuaVisitor ) return ((LuaVisitor<? extends T>)visitor).visitTableconstructor(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TableconstructorContext tableconstructor() throws RecognitionException {
		TableconstructorContext _localctx = new TableconstructorContext(_ctx, getState());
		enterRule(_localctx, 34, RULE_tableconstructor);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(288); match(29);
			setState(290);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << 4) | (1L << 6) | (1L << 8) | (1L << 21) | (1L << 23) | (1L << 25) | (1L << 29) | (1L << 30) | (1L << 34) | (1L << 37) | (1L << 49) | (1L << STRING) | (1L << NAME) | (1L << NUMBER))) != 0)) {
				{
				setState(289); fieldlist();
				}
			}

			setState(292); match(9);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FieldlistContext extends ParserRuleContext {
		public List<FieldsepContext> fieldsep() {
			return getRuleContexts(FieldsepContext.class);
		}
		public FieldContext field(int i) {
			return getRuleContext(FieldContext.class,i);
		}
		public List<FieldContext> field() {
			return getRuleContexts(FieldContext.class);
		}
		public FieldsepContext fieldsep(int i) {
			return getRuleContext(FieldsepContext.class,i);
		}
		public FieldlistContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_fieldlist; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LuaVisitor ) return ((LuaVisitor<? extends T>)visitor).visitFieldlist(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FieldlistContext fieldlist() throws RecognitionException {
		FieldlistContext _localctx = new FieldlistContext(_ctx, getState());
		enterRule(_localctx, 36, RULE_fieldlist);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(294); field();
			setState(300);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,27,_ctx);
			while ( _alt!=2 && _alt!=ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(295); fieldsep();
					setState(296); field();
					}
					} 
				}
				setState(302);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,27,_ctx);
			}
			setState(304);
			_la = _input.LA(1);
			if (_la==20 || _la==43) {
				{
				setState(303); fieldsep();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FieldContext extends ParserRuleContext {
		public List<ExpContext> exp() {
			return getRuleContexts(ExpContext.class);
		}
		public TerminalNode NAME() { return getToken(LuaParser.NAME, 0); }
		public ExpContext exp(int i) {
			return getRuleContext(ExpContext.class,i);
		}
		public FieldContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_field; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LuaVisitor ) return ((LuaVisitor<? extends T>)visitor).visitField(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FieldContext field() throws RecognitionException {
		FieldContext _localctx = new FieldContext(_ctx, getState());
		enterRule(_localctx, 38, RULE_field);
		try {
			setState(316);
			switch ( getInterpreter().adaptivePredict(_input,29,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(306); match(4);
				setState(307); exp(0);
				setState(308); match(18);
				setState(309); match(14);
				setState(310); exp(0);
				}
				break;

			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(312); match(NAME);
				setState(313); match(14);
				setState(314); exp(0);
				}
				break;

			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(315); exp(0);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FieldsepContext extends ParserRuleContext {
		public FieldsepContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_fieldsep; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LuaVisitor ) return ((LuaVisitor<? extends T>)visitor).visitFieldsep(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FieldsepContext fieldsep() throws RecognitionException {
		FieldsepContext _localctx = new FieldsepContext(_ctx, getState());
		enterRule(_localctx, 40, RULE_fieldsep);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(318);
			_la = _input.LA(1);
			if ( !(_la==20 || _la==43) ) {
			_errHandler.recoverInline(this);
			}
			consume();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class BinopContext extends ParserRuleContext {
		public BinopContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_binop; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LuaVisitor ) return ((LuaVisitor<? extends T>)visitor).visitBinop(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BinopContext binop() throws RecognitionException {
		BinopContext _localctx = new BinopContext(_ctx, getState());
		enterRule(_localctx, 42, RULE_binop);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(320);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << 2) | (1L << 3) | (1L << 5) | (1L << 7) | (1L << 11) | (1L << 17) | (1L << 21) | (1L << 28) | (1L << 31) | (1L << 36) | (1L << 39) | (1L << 44) | (1L << 46) | (1L << 47) | (1L << 48))) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			consume();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class UnopContext extends ParserRuleContext {
		public UnopContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_unop; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LuaVisitor ) return ((LuaVisitor<? extends T>)visitor).visitUnop(this);
			else return visitor.visitChildren(this);
		}
	}

	public final UnopContext unop() throws RecognitionException {
		UnopContext _localctx = new UnopContext(_ctx, getState());
		enterRule(_localctx, 44, RULE_unop);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(322);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << 21) | (1L << 25) | (1L << 49))) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			consume();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public boolean sempred(RuleContext _localctx, int ruleIndex, int predIndex) {
		switch (ruleIndex) {
		case 9: return exp_sempred((ExpContext)_localctx, predIndex);

		case 11: return prefixexp_sempred((PrefixexpContext)_localctx, predIndex);
		}
		return true;
	}
	private boolean exp_sempred(ExpContext _localctx, int predIndex) {
		switch (predIndex) {
		case 0: return precpred(_ctx, 2);
		}
		return true;
	}
	private boolean prefixexp_sempred(PrefixexpContext _localctx, int predIndex) {
		switch (predIndex) {
		case 1: return precpred(_ctx, 5);

		case 2: return precpred(_ctx, 4);

		case 3: return precpred(_ctx, 3);

		case 4: return precpred(_ctx, 2);
		}
		return true;
	}

	public static final String _serializedATN =
		"\3\u0430\ud6d1\u8206\uad2d\u4417\uaef1\u8d80\uaadd\3:\u0147\4\2\t\2\4"+
		"\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t"+
		"\13\4\f\t\f\4\r\t\r\4\16\t\16\4\17\t\17\4\20\t\20\4\21\t\21\4\22\t\22"+
		"\4\23\t\23\4\24\t\24\4\25\t\25\4\26\t\26\4\27\t\27\4\30\t\30\3\2\3\2\3"+
		"\2\3\3\7\3\65\n\3\f\3\16\38\13\3\3\3\5\3;\n\3\3\4\3\4\3\4\3\4\3\4\3\4"+
		"\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3"+
		"\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\7\4_\n\4\f\4\16\4b\13\4\3\4"+
		"\3\4\5\4f\n\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\5\4r\n\4\3\4\3\4"+
		"\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3"+
		"\4\3\4\3\4\3\4\5\4\u008b\n\4\5\4\u008d\n\4\3\5\3\5\5\5\u0091\n\5\3\5\5"+
		"\5\u0094\n\5\3\6\3\6\3\6\3\6\3\7\3\7\3\7\7\7\u009d\n\7\f\7\16\7\u00a0"+
		"\13\7\3\7\3\7\5\7\u00a4\n\7\3\b\3\b\3\b\7\b\u00a9\n\b\f\b\16\b\u00ac\13"+
		"\b\3\t\3\t\3\t\7\t\u00b1\n\t\f\t\16\t\u00b4\13\t\3\n\3\n\3\n\7\n\u00b9"+
		"\n\n\f\n\16\n\u00bc\13\n\3\13\3\13\3\13\3\13\3\13\3\13\3\13\3\13\3\13"+
		"\3\13\3\13\3\13\3\13\5\13\u00cb\n\13\3\13\3\13\3\13\3\13\7\13\u00d1\n"+
		"\13\f\13\16\13\u00d4\13\13\3\f\3\f\3\f\3\f\3\f\3\f\3\f\3\f\3\f\3\f\5\f"+
		"\u00e0\n\f\3\r\3\r\3\r\3\r\3\r\3\r\5\r\u00e8\n\r\3\r\3\r\3\r\3\r\3\r\3"+
		"\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r\7\r\u00f8\n\r\f\r\16\r\u00fb\13\r\3"+
		"\16\3\16\3\16\3\16\3\16\3\16\3\16\3\16\5\16\u0105\n\16\3\17\3\17\5\17"+
		"\u0109\n\17\3\17\3\17\3\17\5\17\u010e\n\17\3\20\3\20\3\20\3\21\3\21\5"+
		"\21\u0115\n\21\3\21\3\21\3\21\3\21\3\22\3\22\3\22\5\22\u011e\n\22\3\22"+
		"\5\22\u0121\n\22\3\23\3\23\5\23\u0125\n\23\3\23\3\23\3\24\3\24\3\24\3"+
		"\24\7\24\u012d\n\24\f\24\16\24\u0130\13\24\3\24\5\24\u0133\n\24\3\25\3"+
		"\25\3\25\3\25\3\25\3\25\3\25\3\25\3\25\3\25\5\25\u013f\n\25\3\26\3\26"+
		"\3\27\3\27\3\30\3\30\3\30\2\4\24\30\31\2\4\6\b\n\f\16\20\22\24\26\30\32"+
		"\34\36 \"$&(*,.\2\5\4\2\26\26--\16\2\4\5\7\7\t\t\r\r\23\23\27\27\36\36"+
		"!!&&))..\60\62\5\2\27\27\33\33\63\63\u0167\2\60\3\2\2\2\4\66\3\2\2\2\6"+
		"\u008c\3\2\2\2\b\u008e\3\2\2\2\n\u0095\3\2\2\2\f\u0099\3\2\2\2\16\u00a5"+
		"\3\2\2\2\20\u00ad\3\2\2\2\22\u00b5\3\2\2\2\24\u00ca\3\2\2\2\26\u00df\3"+
		"\2\2\2\30\u00e7\3\2\2\2\32\u0104\3\2\2\2\34\u010d\3\2\2\2\36\u010f\3\2"+
		"\2\2 \u0112\3\2\2\2\"\u0120\3\2\2\2$\u0122\3\2\2\2&\u0128\3\2\2\2(\u013e"+
		"\3\2\2\2*\u0140\3\2\2\2,\u0142\3\2\2\2.\u0144\3\2\2\2\60\61\5\4\3\2\61"+
		"\62\7\2\2\3\62\3\3\2\2\2\63\65\5\6\4\2\64\63\3\2\2\2\658\3\2\2\2\66\64"+
		"\3\2\2\2\66\67\3\2\2\2\67:\3\2\2\28\66\3\2\2\29;\5\b\5\2:9\3\2\2\2:;\3"+
		"\2\2\2;\5\3\2\2\2<\u008d\7-\2\2=>\5\16\b\2>?\7\20\2\2?@\5\22\n\2@\u008d"+
		"\3\2\2\2A\u008d\5\32\16\2B\u008d\5\n\6\2C\u008d\7\"\2\2DE\7\21\2\2E\u008d"+
		"\7\66\2\2FG\7\f\2\2GH\5\4\3\2HI\7\64\2\2I\u008d\3\2\2\2JK\7\30\2\2KL\5"+
		"\24\13\2LM\7\f\2\2MN\5\4\3\2NO\7\64\2\2O\u008d\3\2\2\2PQ\7\22\2\2QR\5"+
		"\4\3\2RS\7\35\2\2ST\5\24\13\2T\u008d\3\2\2\2UV\7\34\2\2VW\5\24\13\2WX"+
		"\7/\2\2X`\5\4\3\2YZ\7%\2\2Z[\5\24\13\2[\\\7/\2\2\\]\5\4\3\2]_\3\2\2\2"+
		"^Y\3\2\2\2_b\3\2\2\2`^\3\2\2\2`a\3\2\2\2ae\3\2\2\2b`\3\2\2\2cd\7#\2\2"+
		"df\5\4\3\2ec\3\2\2\2ef\3\2\2\2fg\3\2\2\2gh\7\64\2\2h\u008d\3\2\2\2ij\7"+
		"*\2\2jk\7\66\2\2kl\7\20\2\2lm\5\24\13\2mn\7\26\2\2nq\5\24\13\2op\7\26"+
		"\2\2pr\5\24\13\2qo\3\2\2\2qr\3\2\2\2rs\3\2\2\2st\7\f\2\2tu\5\4\3\2uv\7"+
		"\64\2\2v\u008d\3\2\2\2wx\7*\2\2xy\5\20\t\2yz\7\25\2\2z{\5\22\n\2{|\7\f"+
		"\2\2|}\5\4\3\2}~\7\64\2\2~\u008d\3\2\2\2\177\u0080\7\'\2\2\u0080\u0081"+
		"\5\f\7\2\u0081\u0082\5 \21\2\u0082\u008d\3\2\2\2\u0083\u0084\7,\2\2\u0084"+
		"\u0085\7\66\2\2\u0085\u008d\5 \21\2\u0086\u0087\7\3\2\2\u0087\u008a\5"+
		"\20\t\2\u0088\u0089\7\20\2\2\u0089\u008b\5\22\n\2\u008a\u0088\3\2\2\2"+
		"\u008a\u008b\3\2\2\2\u008b\u008d\3\2\2\2\u008c<\3\2\2\2\u008c=\3\2\2\2"+
		"\u008cA\3\2\2\2\u008cB\3\2\2\2\u008cC\3\2\2\2\u008cD\3\2\2\2\u008cF\3"+
		"\2\2\2\u008cJ\3\2\2\2\u008cP\3\2\2\2\u008cU\3\2\2\2\u008ci\3\2\2\2\u008c"+
		"w\3\2\2\2\u008c\177\3\2\2\2\u008c\u0083\3\2\2\2\u008c\u0086\3\2\2\2\u008d"+
		"\7\3\2\2\2\u008e\u0090\7+\2\2\u008f\u0091\5\22\n\2\u0090\u008f\3\2\2\2"+
		"\u0090\u0091\3\2\2\2\u0091\u0093\3\2\2\2\u0092\u0094\7-\2\2\u0093\u0092"+
		"\3\2\2\2\u0093\u0094\3\2\2\2\u0094\t\3\2\2\2\u0095\u0096\7\17\2\2\u0096"+
		"\u0097\7\66\2\2\u0097\u0098\7\17\2\2\u0098\13\3\2\2\2\u0099\u009e\7\66"+
		"\2\2\u009a\u009b\7(\2\2\u009b\u009d\7\66\2\2\u009c\u009a\3\2\2\2\u009d"+
		"\u00a0\3\2\2\2\u009e\u009c\3\2\2\2\u009e\u009f\3\2\2\2\u009f\u00a3\3\2"+
		"\2\2\u00a0\u009e\3\2\2\2\u00a1\u00a2\7\32\2\2\u00a2\u00a4\7\66\2\2\u00a3"+
		"\u00a1\3\2\2\2\u00a3\u00a4\3\2\2\2\u00a4\r\3\2\2\2\u00a5\u00aa\5\26\f"+
		"\2\u00a6\u00a7\7\26\2\2\u00a7\u00a9\5\26\f\2\u00a8\u00a6\3\2\2\2\u00a9"+
		"\u00ac\3\2\2\2\u00aa\u00a8\3\2\2\2\u00aa\u00ab\3\2\2\2\u00ab\17\3\2\2"+
		"\2\u00ac\u00aa\3\2\2\2\u00ad\u00b2\7\66\2\2\u00ae\u00af\7\26\2\2\u00af"+
		"\u00b1\7\66\2\2\u00b0\u00ae\3\2\2\2\u00b1\u00b4\3\2\2\2\u00b2\u00b0\3"+
		"\2\2\2\u00b2\u00b3\3\2\2\2\u00b3\21\3\2\2\2\u00b4\u00b2\3\2\2\2\u00b5"+
		"\u00ba\5\24\13\2\u00b6\u00b7\7\26\2\2\u00b7\u00b9\5\24\13\2\u00b8\u00b6"+
		"\3\2\2\2\u00b9\u00bc\3\2\2\2\u00ba\u00b8\3\2\2\2\u00ba\u00bb\3\2\2\2\u00bb"+
		"\23\3\2\2\2\u00bc\u00ba\3\2\2\2\u00bd\u00be\b\13\1\2\u00be\u00bf\5.\30"+
		"\2\u00bf\u00c0\5\24\13\3\u00c0\u00cb\3\2\2\2\u00c1\u00cb\7\n\2\2\u00c2"+
		"\u00cb\7\b\2\2\u00c3\u00cb\7$\2\2\u00c4\u00cb\7\67\2\2\u00c5\u00cb\7\65"+
		"\2\2\u00c6\u00cb\7 \2\2\u00c7\u00cb\5\36\20\2\u00c8\u00cb\5\30\r\2\u00c9"+
		"\u00cb\5$\23\2\u00ca\u00bd\3\2\2\2\u00ca\u00c1\3\2\2\2\u00ca\u00c2\3\2"+
		"\2\2\u00ca\u00c3\3\2\2\2\u00ca\u00c4\3\2\2\2\u00ca\u00c5\3\2\2\2\u00ca"+
		"\u00c6\3\2\2\2\u00ca\u00c7\3\2\2\2\u00ca\u00c8\3\2\2\2\u00ca\u00c9\3\2"+
		"\2\2\u00cb\u00d2\3\2\2\2\u00cc\u00cd\f\4\2\2\u00cd\u00ce\5,\27\2\u00ce"+
		"\u00cf\5\24\13\5\u00cf\u00d1\3\2\2\2\u00d0\u00cc\3\2\2\2\u00d1\u00d4\3"+
		"\2\2\2\u00d2\u00d0\3\2\2\2\u00d2\u00d3\3\2\2\2\u00d3\25\3\2\2\2\u00d4"+
		"\u00d2\3\2\2\2\u00d5\u00e0\7\66\2\2\u00d6\u00d7\5\30\r\2\u00d7\u00d8\7"+
		"\6\2\2\u00d8\u00d9\5\24\13\2\u00d9\u00da\7\24\2\2\u00da\u00e0\3\2\2\2"+
		"\u00db\u00dc\5\30\r\2\u00dc\u00dd\7(\2\2\u00dd\u00de\7\66\2\2\u00de\u00e0"+
		"\3\2\2\2\u00df\u00d5\3\2\2\2\u00df\u00d6\3\2\2\2\u00df\u00db\3\2\2\2\u00e0"+
		"\27\3\2\2\2\u00e1\u00e2\b\r\1\2\u00e2\u00e8\7\66\2\2\u00e3\u00e4\7\31"+
		"\2\2\u00e4\u00e5\5\24\13\2\u00e5\u00e6\7\16\2\2\u00e6\u00e8\3\2\2\2\u00e7"+
		"\u00e1\3\2\2\2\u00e7\u00e3\3\2\2\2\u00e8\u00f9\3\2\2\2\u00e9\u00ea\f\7"+
		"\2\2\u00ea\u00eb\7\6\2\2\u00eb\u00ec\5\24\13\2\u00ec\u00ed\7\24\2\2\u00ed"+
		"\u00f8\3\2\2\2\u00ee\u00ef\f\6\2\2\u00ef\u00f0\7(\2\2\u00f0\u00f8\7\66"+
		"\2\2\u00f1\u00f2\f\5\2\2\u00f2\u00f8\5\34\17\2\u00f3\u00f4\f\4\2\2\u00f4"+
		"\u00f5\7\32\2\2\u00f5\u00f6\7\66\2\2\u00f6\u00f8\5\34\17\2\u00f7\u00e9"+
		"\3\2\2\2\u00f7\u00ee\3\2\2\2\u00f7\u00f1\3\2\2\2\u00f7\u00f3\3\2\2\2\u00f8"+
		"\u00fb\3\2\2\2\u00f9\u00f7\3\2\2\2\u00f9\u00fa\3\2\2\2\u00fa\31\3\2\2"+
		"\2\u00fb\u00f9\3\2\2\2\u00fc\u00fd\5\30\r\2\u00fd\u00fe\5\34\17\2\u00fe"+
		"\u0105\3\2\2\2\u00ff\u0100\5\30\r\2\u0100\u0101\7\32\2\2\u0101\u0102\7"+
		"\66\2\2\u0102\u0103\5\34\17\2\u0103\u0105\3\2\2\2\u0104\u00fc\3\2\2\2"+
		"\u0104\u00ff\3\2\2\2\u0105\33\3\2\2\2\u0106\u0108\7\31\2\2\u0107\u0109"+
		"\5\22\n\2\u0108\u0107\3\2\2\2\u0108\u0109\3\2\2\2\u0109\u010a\3\2\2\2"+
		"\u010a\u010e\7\16\2\2\u010b\u010e\5$\23\2\u010c\u010e\7\65\2\2\u010d\u0106"+
		"\3\2\2\2\u010d\u010b\3\2\2\2\u010d\u010c\3\2\2\2\u010e\35\3\2\2\2\u010f"+
		"\u0110\7\'\2\2\u0110\u0111\5 \21\2\u0111\37\3\2\2\2\u0112\u0114\7\31\2"+
		"\2\u0113\u0115\5\"\22\2\u0114\u0113\3\2\2\2\u0114\u0115\3\2\2\2\u0115"+
		"\u0116\3\2\2\2\u0116\u0117\7\16\2\2\u0117\u0118\5\4\3\2\u0118\u0119\7"+
		"\64\2\2\u0119!\3\2\2\2\u011a\u011d\5\20\t\2\u011b\u011c\7\26\2\2\u011c"+
		"\u011e\7 \2\2\u011d\u011b\3\2\2\2\u011d\u011e\3\2\2\2\u011e\u0121\3\2"+
		"\2\2\u011f\u0121\7 \2\2\u0120\u011a\3\2\2\2\u0120\u011f\3\2\2\2\u0121"+
		"#\3\2\2\2\u0122\u0124\7\37\2\2\u0123\u0125\5&\24\2\u0124\u0123\3\2\2\2"+
		"\u0124\u0125\3\2\2\2\u0125\u0126\3\2\2\2\u0126\u0127\7\13\2\2\u0127%\3"+
		"\2\2\2\u0128\u012e\5(\25\2\u0129\u012a\5*\26\2\u012a\u012b\5(\25\2\u012b"+
		"\u012d\3\2\2\2\u012c\u0129\3\2\2\2\u012d\u0130\3\2\2\2\u012e\u012c\3\2"+
		"\2\2\u012e\u012f\3\2\2\2\u012f\u0132\3\2\2\2\u0130\u012e\3\2\2\2\u0131"+
		"\u0133\5*\26\2\u0132\u0131\3\2\2\2\u0132\u0133\3\2\2\2\u0133\'\3\2\2\2"+
		"\u0134\u0135\7\6\2\2\u0135\u0136\5\24\13\2\u0136\u0137\7\24\2\2\u0137"+
		"\u0138\7\20\2\2\u0138\u0139\5\24\13\2\u0139\u013f\3\2\2\2\u013a\u013b"+
		"\7\66\2\2\u013b\u013c\7\20\2\2\u013c\u013f\5\24\13\2\u013d\u013f\5\24"+
		"\13\2\u013e\u0134\3\2\2\2\u013e\u013a\3\2\2\2\u013e\u013d\3\2\2\2\u013f"+
		")\3\2\2\2\u0140\u0141\t\2\2\2\u0141+\3\2\2\2\u0142\u0143\t\3\2\2\u0143"+
		"-\3\2\2\2\u0144\u0145\t\4\2\2\u0145/\3\2\2\2 \66:`eq\u008a\u008c\u0090"+
		"\u0093\u009e\u00a3\u00aa\u00b2\u00ba\u00ca\u00d2\u00df\u00e7\u00f7\u00f9"+
		"\u0104\u0108\u010d\u0114\u011d\u0120\u0124\u012e\u0132\u013e";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}